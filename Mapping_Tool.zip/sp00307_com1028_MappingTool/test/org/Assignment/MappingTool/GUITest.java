package org.Assignment.MappingTool;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class GUITest {

	/**
	 * Constructor Test
	 */
	@Test
	public void constructionTest(){
		GUI i = new GUI();		//Checks that the GUI can be constructed properly
	}
}
